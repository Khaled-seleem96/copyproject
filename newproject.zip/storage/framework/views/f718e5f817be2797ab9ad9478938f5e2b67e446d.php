<?php $__env->startSection('content'); ?>


<div class="col-md-10 col-10" style="margin-top: 50px;">
            <div class="container section1" >
            <table class="table table-dark">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">اسم المستخدم</th>
      <th scope="col">رقم الهاتف</th>
      <th scope="col">البريد الالكتروني</th>

    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr> 
      <th> <?php echo e($d->orderId); ?></th>
      <td> <?php echo e($d->name); ?></td>
      <td> <?php echo e($d->phone); ?></td>
      <td> <?php echo e($d->email); ?></td>
      <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="<?php echo e('#modal'.$d->orderId); ?>" > المزيد</button></td>
      <td><a href="/deletemsg/<?php echo e($d->id); ?>" class="btn ">حذف</a></td>
<td><?php echo e(($d->comment)?'Done':'No comment yet'); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
            
            </div>
        </div>


        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="modal fade" data-name="<?php echo e($d->name); ?>" id="<?php echo e('modal'.$d->orderId); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLongTitle">الحجوزات</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <form method="post" action="<?php echo e(action('adminController@updateOrderComment')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="modal-body">
                  <h5 class="text" style="float: right;">اسم العميل</h5>
                  <p class="text" ><?php echo e($d->name); ?></p>
                  <hr>
                  <h5 class="text" style="float: right;">العنوان</h5>
                  <p class="text" ><?php echo e($d->address); ?></p>
                  <hr>
                  <h5 class="text" style="float: right;">رقم الهاتف</h5>
                  <p class="text" ><?php echo e($d->phone); ?></p>
                  <hr>
                  <h5 class="text" style="float: right;">المطلوب</h5>
                  <br><br>
                  <h4 class="" style="float: right;color:black !important"><?php echo e($d->msg); ?></h4>
                  <br><br>
                  <input type="hidden" name="id" value='<?php echo e($d->orderId); ?>'>
                  <hr>
                  <h5 class="text" style="float: right;">أضف تعليق</h5>
                  <br><br>
                  <textarea  class="form-control" name="comment" cols="20" rows="10" placeholder="أضف تعليق" style="width: 100%;height:100px" required><?php echo e(@$d->comment); ?></textarea>
               </div>
                <div style="margin:20px">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Save changes</button>
                </div> 
                
                </form>
              </div>
            </div>
          </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>