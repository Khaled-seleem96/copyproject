<?php $__env->startSection('content'); ?>


<div class="col-md-8 col-8" style="margin-top: 50px;">
            <div class="container section1" >
            <form action="<?php echo e(route('insert')); ?>" method="post" enctype="multipart/form-data" >
            <?php echo e(csrf_field()); ?>

            <input type="file" name="img">
            <input type="text" name="title">
            </form>
            </div>
        </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>