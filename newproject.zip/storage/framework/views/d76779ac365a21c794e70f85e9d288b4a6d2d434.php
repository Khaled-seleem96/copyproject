<?php $__env->startSection('title','Gallery'); ?>
<?php $__env->startSection('user'); ?>


    <!-- Page Content -->
    <div class="container "  >



<div class="row "  style="padding-top:100px">

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-3 col-md-4 col-xs-6 thumb">
        <a href="<?php echo e(asset($d->img)); ?>" class="fancybox" rel="ligthbox">
            <img  src="<?php echo e(asset($d->img)); ?>" class="zoom img-fluid "  alt="">
           
        </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
    
   
   
</div>
</div>

<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>