<?php $__env->startSection('content'); ?>


<div class="col-md-10 col-10" style="margin-top: 50px;">
            <div class="container section1" >
            <table class="table table-dark">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">الصور</th>
      <th scope="col">العنوان</th>
      
      <th scope="col">تغير الصور</th>
      <th scope="col">حذف الصور</th>
      
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($d->id); ?></th>
      <td><img src="<?php echo e(asset($d->img)); ?>" alt="this is image" width='80px'></td>
      <td><?php echo e($d->title); ?></td>
      
      <td><a href="/edit/<?php echo e($d->id); ?>" class="btn ">تغير</a></td>
      <td><a href="/delete/<?php echo e($d->id); ?>" class="btn ">حذف</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<a href="<?php echo e(route('upload')); ?>" class="btn ">اضافه الصور</a>
            </div>
        </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>