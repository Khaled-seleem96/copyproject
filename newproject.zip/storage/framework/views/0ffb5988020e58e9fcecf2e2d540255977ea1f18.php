<style>body{background:white !important;}</style>

<?php $__env->startSection('title', Auth::user()->name ); ?>
<?php $__env->startSection('user'); ?>
<div class="container" > 
  <div class="row" >
  <div class="col-md-12 col-12" style="margin-top: 50px;">
            <div class="container section1" >
                <div class="text" style="text-align:center">الصفحه الشخصيه</div>

  <?php if(count($data) > 0): ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div class="col-md-10 offset-md-1 "  >
      <div class="card col-md-12 " style=" margin-top: 20px;border: 1px solid #ff8d1e;">
            <br>
      <h4 class="text" style="justify-content:right;display:flex;">العنوان</h4>
      <p class="text" style="justify-content:right;display:flex;color:black !important;padding-bottom:0px"><?php echo e(($d->address)); ?></p>
      <hr>
      <h4 class="text" style="justify-content:right;display:flex">رقم الهاتف</h4>
      <p class="text" style="justify-content:right;display:flex;color:black !important"><?php echo e(($d->phone)); ?></p>
      <hr>
      <h4 class="text" style="justify-content:right;display:flex">الحجز الذي قمت به</h4>
      <p class="text" style="justify-content:right;display:flex;color:black !important"><?php echo e(($d->msg)); ?></p>
      <hr>
      <?php if(!empty($d->comment)): ?>
      <h4 class="text" style="justify-content:right;display:flex">تعليق الاداره</h5>
      <h2 style="justify-content:right;display:flex;color:black !important"><?php echo e(($d->comment)); ?></h2>
      <?php else: ?>
      <h2 class="text" style="text-align:center">لا تعليق حتى الان</h2>
      <?php endif; ?>
        <div class="card-body">
          <a href="/reservation/<?php echo e($d->orderId); ?>" class="btn btn-primary bsec1" style="justify-content:right;display:flex;">حذف الحجز</a>
        </div>
        

        </div>
      </div>          
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
    <hr><br><br>
    <h2 class="text" style="text-align:center">لا يوجد حجز حتى الان</h2>
  <?php endif; ?>
            </div>
        </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>