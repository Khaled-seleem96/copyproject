<?php $__env->startSection('content'); ?>


<div class="col-md-8 col-8" style="margin-top: 50px;">
            <div class="container section1" >
            <form action="<?php echo e(route('update',['id'=>$d->id])); ?>" method="post" enctype="multipart/form-data" >
            <?php echo e(csrf_field()); ?>

            <img src="<?php echo e(asset($d->img)); ?>" alt="" width='50px'>
            <input name='img' type="file" class="form-control" placeholder='Enter Post Title'>
            <br><br>
            <input type="text" name="title" value='<?php echo e($d->title); ?>'>
            </form>
            </div>
        </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>