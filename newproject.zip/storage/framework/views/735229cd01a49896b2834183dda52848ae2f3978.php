<?php $__env->startSection('content'); ?>
<div class="col-md-10 col-10" style="margin-top: 50px;">
<div class="container section1" >
<table class="table table-dark">
<thead><tr><th scope="col">الاسم</th>
<th scope="col"> البريد الالكتروني</th>
<th scope="col">رقم الهاتف</th>
<th scope="col">حذف المستخدم</th>
</tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($d->name); ?></th>
      <td><?php echo e($d->email); ?></td>
      <td><?php echo e($d->phone); ?></td>
      <td><a href="/deleteuser/<?php echo e($d->id); ?>" class="btn ">حذف</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
        </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>