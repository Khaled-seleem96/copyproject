<?php $__env->startSection('title','Admin'); ?>
<?php $__env->startSection('content'); ?>
        <div class="col-md-10 col-8" style="margin-top: 50px;">
            <div class="container section1" >
                <h1 class="text" style="text-align:center">أهلا بكم من جديد</h1>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

<br><br>
                    <h4 class="text" style="text-align:center">نحن هنا لمساعدة المستخدمين</h4>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>